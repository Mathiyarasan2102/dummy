import React from 'react';
import Navbar from './Navbar';

const Layout = ({ children }) => {
    return (
        <div className="min-h-screen bg-navy-900 flex flex-col">
            <Navbar />
            <main className="flex-grow">
                {children}
            </main>
            <footer className="bg-navy-900 border-t border-navy-800 py-8">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <p className="text-center text-gray-400 text-sm">
                        &copy; {new Date().getFullYear()} LuxeEstate. All rights reserved.
                    </p>
                </div>
            </footer>
        </div>
    );
};

export default Layout;
