import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import Layout from '../components/layout/Layout';
import { ArrowRight, Search, Home as HomeIcon, Key, Star } from 'lucide-react';

const Home = () => {
    return (
        <Layout>
            {/* Hero Section */}
            <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 bg-navy-900">
                    <div className="absolute inset-0 bg-gradient-to-r from-navy-900/90 to-navy-900/40 z-10"></div>
                    {/* Placeholder for video or hero image */}
                    <img
                        src="https://images.unsplash.com/photo-1600596542815-2a4f04d743ea?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80"
                        alt="Luxury Home"
                        className="w-full h-full object-cover opacity-50"
                    />
                </div>

                <div className="relative z-20 container mx-auto px-4 text-center">
                    <motion.h1
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                        className="text-5xl md:text-7xl font-serif font-bold text-cream mb-6"
                    >
                        Experience <span className="text-gold-400">Luxury</span> Living
                    </motion.h1>
                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.2 }}
                        className="text-xl md:text-2xl text-gray-300 mb-10 max-w-2xl mx-auto font-light"
                    >
                        Discover the world's most exclusive properties in the most desirable locations.
                    </motion.p>
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.4 }}
                        className="flex justify-center gap-4"
                    >
                        <Link to="/properties" className="btn-primary flex items-center gap-2">
                            Explore Properties <ArrowRight size={20} />
                        </Link>
                        <Link to="/contact" className="btn-outline">
                            Contact Agent
                        </Link>
                    </motion.div>
                </div>
            </section>

            {/* Features Preview */}
            <section className="py-20 bg-navy-800">
                <div className="container mx-auto px-4">
                    <div className="grid md:grid-cols-3 gap-10">
                        <motion.div
                            whileHover={{ y: -5 }}
                            className="text-center p-8 bg-navy-900 rounded-lg border border-navy-700 hover:border-gold-400 transition-colors"
                        >
                            <HomeIcon className="mx-auto text-gold-400 mb-4" size={40} />
                            <h3 className="text-xl font-bold text-cream mb-2">Premium Listings</h3>
                            <p className="text-gray-400">Curated selection of high-end homes.</p>
                        </motion.div>
                        <motion.div
                            whileHover={{ y: -5 }}
                            className="text-center p-8 bg-navy-900 rounded-lg border border-navy-700 hover:border-gold-400 transition-colors"
                        >
                            <Key className="mx-auto text-gold-400 mb-4" size={40} />
                            <h3 className="text-xl font-bold text-cream mb-2">Secure Transactions</h3>
                            <p className="text-gray-400">Verified properties and agents.</p>
                        </motion.div>
                        <motion.div
                            whileHover={{ y: -5 }}
                            className="text-center p-8 bg-navy-900 rounded-lg border border-navy-700 hover:border-gold-400 transition-colors"
                        >
                            <Star className="mx-auto text-gold-400 mb-4" size={40} />
                            <h3 className="text-xl font-bold text-cream mb-2">Top Rated Service</h3>
                            <p className="text-gray-400">Experience world-class support.</p>
                        </motion.div>
                    </div>
                </div>
            </section>
        </Layout>
    );
};

export default Home;
